import { supabase } from "./app.js";

const page = document.querySelector("#readerPage");
const params = new URLSearchParams(location.search);
const storyId = params.get("story");
const chapterId = params.get("chapter");

function escapeHtml(text = "") {
  return text.replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}
function paragraphs(text = "") {
  return text.split(/\r?\n\r?\n+/).map(p => p.trim()).filter(Boolean).map(p => `<p>${escapeHtml(p).replace(/\r?\n/g, "<br>")}</p>`).join("");
}

async function init() {
  if (!storyId || !chapterId) throw new Error("Missing parameters");
  const [{ data: story }, { data: chapter }, { data: chapters }] = await Promise.all([
    supabase.from("stories").select("id,title").eq("id", storyId).single(),
    supabase.from("chapters").select("id,title,chapter_number,content").eq("id", chapterId).single(),
    supabase.from("chapters").select("id,title,chapter_number").eq("story_id", storyId).order("chapter_number", { ascending: true })
  ]);
  if (!story || !chapter) throw new Error("Not found");

  const currentIndex = chapters.findIndex(c => c.id === chapter.id);
  const prev = currentIndex > 0 ? chapters[currentIndex - 1] : null;
  const next = currentIndex >= 0 && currentIndex < chapters.length - 1 ? chapters[currentIndex + 1] : null;
  document.title = `${chapter.title} — ${story.title}`;
  document.querySelector("#backLink").href = `story.html?id=${encodeURIComponent(storyId)}`;

  page.innerHTML = `
    <article class="reader">
      <p class="eyebrow">${escapeHtml(story.title)}</p>
      <h1>${escapeHtml(chapter.title)}</h1>
      <div class="reader-meta">Chương ${chapter.chapter_number}</div>
      <div class="reader-content">${paragraphs(chapter.content)}</div>
      <div class="reader-nav">
        ${prev ? `<a class="button ghost" href="reader.html?story=${storyId}&chapter=${prev.id}">← Chương trước</a>` : `<span></span>`}
        ${next ? `<a class="button" href="reader.html?story=${storyId}&chapter=${next.id}">Chương sau →</a>` : `<a class="button" href="story.html?id=${storyId}">Danh sách chapter</a>`}
      </div>
    </article>`;
}

init().catch(err => { console.error(err); page.innerHTML = `<div class="error">Không thể tải chapter.</div>`; });
