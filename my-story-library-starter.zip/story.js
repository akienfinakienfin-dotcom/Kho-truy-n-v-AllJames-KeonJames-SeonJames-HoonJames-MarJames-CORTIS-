import { supabase } from "./app.js";

const page = document.querySelector("#storyPage");
const params = new URLSearchParams(location.search);
const id = params.get("id");

function escapeHtml(text = "") {
  return text.replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}

async function init() {
  if (!id) {
    page.innerHTML = `<div class="error">Không tìm thấy truyện.</div>`;
    return;
  }

  const [{ data: story, error: storyErr }, { data: chapters, error: chapterErr }] = await Promise.all([
    supabase.from("stories").select("id,title,description,cover_url").eq("id", id).single(),
    supabase.from("chapters").select("id,title,chapter_number").eq("story_id", id).order("chapter_number", { ascending: true })
  ]);

  if (storyErr || chapterErr || !story) {
    page.innerHTML = `<div class="error">Không thể tải truyện.</div>`;
    console.error(storyErr || chapterErr);
    return;
  }

  document.title = story.title;
  page.innerHTML = `
    <section class="story-hero">
      <div class="large-cover">${story.cover_url ? `<img src="${story.cover_url}" alt="Bìa ${escapeHtml(story.title)}">` : `<span>NO COVER</span>`}</div>
      <div>
        <p class="eyebrow">TRUYỆN</p>
        <h1>${escapeHtml(story.title)}</h1>
        <p class="story-desc">${escapeHtml(story.description || "")}</p>
        <a class="button" href="reader.html?story=${encodeURIComponent(id)}&chapter=${chapters?.[0]?.id || ""}">${chapters?.length ? "Đọc từ đầu" : "Chưa có chapter"}</a>
      </div>
    </section>

    <section class="panel chapter-panel">
      <div class="section-head"><h2>Danh sách chapter</h2><span>${chapters?.length || 0} chapter</span></div>
      <div class="chapter-list">
        ${(chapters || []).map(c => `<a href="reader.html?story=${encodeURIComponent(id)}&chapter=${encodeURIComponent(c.id)}"><span>Chương ${c.chapter_number}</span><strong>${escapeHtml(c.title)}</strong><span>→</span></a>`).join("") || `<div class="empty">Chưa có chapter.</div>`}
      </div>
    </section>
  `;
}

init().catch(err => { console.error(err); page.innerHTML = `<div class="error">Có lỗi xảy ra.</div>`; });
