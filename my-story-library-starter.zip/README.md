# My Story Library

Một website thư viện truyện cá nhân đơn giản:
- Trang chủ: bìa + tên + mô tả + nút Đọc truyện
- Mỗi truyện có trang riêng với danh sách chapter
- Mỗi chapter có trang đọc riêng và nút chương trước/sau
- Trang quản lý riêng để thêm truyện, ảnh bìa, chapter
- Có thể nạp nội dung từ TXT hoặc DOCX

## Cấu trúc

- `index.html` — trang chủ
- `story.html` — trang của một bộ truyện
- `reader.html` — trình đọc
- `admin.html` — trang quản lý
- `styles.css` — giao diện
- `app.js`, `story.js`, `reader.js`, `admin.js` — chức năng
- `config.example.js` — mẫu cấu hình Supabase
- `supabase.sql` — tạo database + quyền đọc/ghi

## Cách đưa lên mạng

1. Tạo project Supabase.
2. Trong SQL Editor, chạy `supabase.sql`.
3. Tạo Storage bucket tên `covers` và để public.
4. Tạo tài khoản cho riêng bạn trong Authentication.
5. Tắt public sign-up sau khi tạo tài khoản quản trị.
6. Sao chép `config.example.js` thành `config.js`, sau đó điền Supabase URL và publishable/anon key.
7. Đẩy thư mục này lên GitHub và bật GitHub Pages.

Không đưa `service_role` key vào website.
