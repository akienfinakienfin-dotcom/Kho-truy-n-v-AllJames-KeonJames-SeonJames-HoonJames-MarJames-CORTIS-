// Đổi tên file này thành config.js rồi điền thông tin project Supabase của bạn.
// Không điền service_role key vào đây. Chỉ dùng anon/publishable key.
export const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
export const SUPABASE_ANON_KEY = "YOUR-PUBLISHABLE-KEY";

// Tên bucket ảnh bìa trong Supabase Storage.
export const COVER_BUCKET = "covers";
