-- 1) Chạy toàn bộ SQL này trong Supabase -> SQL Editor.
-- 2) Sau đó tạo Storage bucket tên: covers
-- 3) Tạo tài khoản đăng nhập cho riêng bạn trong Authentication.
-- 4) Nếu muốn chỉ mình bạn được phép thêm/sửa/xóa, hãy tắt public sign-up
--    sau khi tạo xong tài khoản quản trị.

create extension if not exists pgcrypto;

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  cover_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  story_id uuid not null references public.stories(id) on delete cascade,
  chapter_number integer not null,
  title text not null,
  content text not null,
  created_at timestamptz not null default now(),
  unique(story_id, chapter_number)
);

alter table public.stories enable row level security;
alter table public.chapters enable row level security;

-- Ai cũng được đọc.
create policy "public read stories"
on public.stories for select
using (true);

create policy "public read chapters"
on public.chapters for select
using (true);

-- Người đã đăng nhập mới được quản lý nội dung.
-- Hãy tắt public sign-up sau khi tạo tài khoản của bạn.
create policy "authenticated manage stories"
on public.stories for all
to authenticated
using (true)
with check (true);

create policy "authenticated manage chapters"
on public.chapters for all
 to authenticated
using (true)
with check (true);

-- Storage: tạo bucket covers và đặt public = true.
-- Chính sách này cho phép khách xem ảnh; người đã đăng nhập mới được upload/update/delete.
create policy "public view covers"
on storage.objects for select
using (bucket_id = 'covers');

create policy "authenticated upload covers"
on storage.objects for insert
to authenticated
with check (bucket_id = 'covers');

create policy "authenticated update covers"
on storage.objects for update
 to authenticated
using (bucket_id = 'covers')
with check (bucket_id = 'covers');

create policy "authenticated delete covers"
on storage.objects for delete
 to authenticated
using (bucket_id = 'covers');
