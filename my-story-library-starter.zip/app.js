import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./config.js";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export async function getStories() {
  const { data, error } = await supabase
    .from("stories")
    .select("id,title,description,cover_url,created_at")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

const grid = document.querySelector("#storyGrid");
const search = document.querySelector("#search");
const status = document.querySelector("#status");
let stories = [];

function escapeHtml(text = "") {
  return text.replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}

function render(list) {
  if (!list.length) {
    grid.innerHTML = `<div class="empty">Chưa có truyện nào.</div>`;
    return;
  }
  grid.innerHTML = list.map(s => `
    <a class="story-card" href="story.html?id=${encodeURIComponent(s.id)}">
      <div class="cover">${s.cover_url ? `<img src="${s.cover_url}" alt="Bìa ${escapeHtml(s.title)}">` : `<span>NO COVER</span>`}</div>
      <div class="story-info">
        <h2>${escapeHtml(s.title)}</h2>
        <p>${escapeHtml(s.description || "Chưa có mô tả.")}</p>
        <span class="read-link">Đọc truyện →</span>
      </div>
    </a>`).join("");
}

async function init() {
  try {
    stories = await getStories();
    status.textContent = `${stories.length} bộ truyện`;
    render(stories);
  } catch (e) {
    status.textContent = "Chưa kết nối dữ liệu";
    grid.innerHTML = `<div class="error">Hãy kiểm tra file config.js và Supabase.</div>`;
    console.error(e);
  }
}

search?.addEventListener("input", () => {
  const q = search.value.trim().toLowerCase();
  render(stories.filter(s => (s.title + " " + (s.description || "")).toLowerCase().includes(q)));
});

init();
