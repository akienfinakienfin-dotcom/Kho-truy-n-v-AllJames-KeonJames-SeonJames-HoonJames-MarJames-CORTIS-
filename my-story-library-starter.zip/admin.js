import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SUPABASE_URL, SUPABASE_ANON_KEY, COVER_BUCKET } from "./config.js";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const $ = id => document.getElementById(id);

const loginPanel = $("loginPanel");
const adminPanel = $("adminPanel");

function msg(id, text, ok=false) {
  const el = $(id); el.textContent = text; el.className = `message ${ok ? "ok" : "bad"}`;
}

async function refreshSession() {
  const { data } = await supabase.auth.getSession();
  const logged = !!data.session;
  loginPanel.classList.toggle("hidden", logged);
  adminPanel.classList.toggle("hidden", !logged);
  if (logged) await loadStories();
}

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const { error } = await supabase.auth.signInWithPassword({ email: $("email").value, password: $("password").value });
  if (error) return msg("loginMsg", error.message);
  msg("loginMsg", "Đăng nhập thành công.", true);
  await refreshSession();
});

$("logoutBtn").addEventListener("click", async () => { await supabase.auth.signOut(); await refreshSession(); });

async function loadStories() {
  const { data, error } = await supabase.from("stories").select("id,title").order("created_at", { ascending: false });
  if (error) { msg("storyMsg", error.message); return; }
  $("storySelect").innerHTML = (data || []).map(s => `<option value="${s.id}">${escapeHtml(s.title)}</option>`).join("");
}

function escapeHtml(text = "") { return text.replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c])); }

$("coverFile").addEventListener("change", e => {
  const file = e.target.files?.[0];
  if (file) msg("storyMsg", `${file.name} đã được chọn.`, true);
});

$("chapterFile").addEventListener("change", async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    if (file.name.toLowerCase().endsWith(".txt")) {
      $("chapterContent").value = await file.text();
      msg("chapterMsg", "Đã đọc file TXT.", true);
      return;
    }
    if (file.name.toLowerCase().endsWith(".docx")) {
      if (!window.mammoth) throw new Error("Chưa tải được bộ đọc DOCX.");
      const result = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
      $("chapterContent").value = result.value;
      msg("chapterMsg", "Đã đọc file DOCX. Hãy kiểm tra nội dung trước khi thêm chapter.", true);
    }
  } catch (err) { msg("chapterMsg", err.message); }
});

$("storyForm").addEventListener("submit", async e => {
  e.preventDefault();
  const title = $("storyTitle").value.trim();
  const description = $("storyDescription").value.trim();
  const file = $("coverFile").files?.[0];
  let cover_url = null;
  try {
    if (file) {
      const safeName = `${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: uploadError } = await supabase.storage.from(COVER_BUCKET).upload(safeName, file, { upsert: false, contentType: file.type });
      if (uploadError) throw uploadError;
      cover_url = supabase.storage.from(COVER_BUCKET).getPublicUrl(safeName).data.publicUrl;
    }
    const { error } = await supabase.from("stories").insert({ title, description, cover_url });
    if (error) throw error;
    msg("storyMsg", "Đã tạo truyện.", true);
    e.target.reset();
    await loadStories();
  } catch (err) { msg("storyMsg", err.message); }
});

$("chapterForm").addEventListener("submit", async e => {
  e.preventDefault();
  const story_id = $("storySelect").value;
  const chapter_number = Number($("chapterNumber").value);
  const title = $("chapterTitle").value.trim();
  const content = $("chapterContent").value.trim();
  try {
    const { error } = await supabase.from("chapters").insert({ story_id, chapter_number, title, content });
    if (error) throw error;
    msg("chapterMsg", "Đã thêm chapter.", true);
    $("chapterNumber").value = chapter_number + 1;
    $("chapterTitle").value = "";
    $("chapterContent").value = "";
    $("chapterFile").value = "";
  } catch (err) { msg("chapterMsg", err.message); }
});

refreshSession();
